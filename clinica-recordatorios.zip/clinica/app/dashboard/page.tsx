import { createClient } from "@/lib/supabase/server";
import Link from "next/link";

export default async function Dashboard() {
  const supabase = await createClient();
  const { data: pacientes } = await supabase
    .from("pacientes")
    .select("id, nombre, edad, telefono, email")
    .order("creado_en", { ascending: false });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">Pacientes</h1>
        <Link
          href="/dashboard/pacientes/nuevo"
          className="bg-marca text-white text-sm rounded-lg px-4 py-2 font-medium active:bg-marcaOscuro"
        >
          + Nuevo
        </Link>
      </div>

      {!pacientes || pacientes.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center text-slate-500">
          Aún no hay pacientes. Toca <b>+ Nuevo</b> para registrar el primero.
        </div>
      ) : (
        <ul className="space-y-2">
          {pacientes.map((p) => (
            <li key={p.id}>
              <Link
                href={`/dashboard/pacientes/${p.id}`}
                className="block bg-white rounded-xl p-4 shadow-sm active:bg-slate-50"
              >
                <div className="font-medium">{p.nombre}</div>
                <div className="text-sm text-slate-500">
                  {p.edad ? `${p.edad} años · ` : ""}
                  {p.telefono || p.email || "sin contacto"}
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
